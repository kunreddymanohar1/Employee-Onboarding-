product=[
    {
        'name': 'sai',
        'age': 20,
        'place': 'hyd'
    },
    {
        'name': 'sai2',
        'age': 19,
        'place': 'chennai'
    },
    {
        'name': 'sai3',
        'age': 18,
        'place': 'banglore'
    },
]