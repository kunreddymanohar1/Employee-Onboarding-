import React from 'react'
import './About.css'
import Dashheader from './Dashheader'
import Companyinfo from './Companyinfo'
import Footer from './copyfoot'

const About = () => {
  return (
    <>
    <Dashheader />
    <Companyinfo />
    <Footer />
    </>

  )
}

export default About






