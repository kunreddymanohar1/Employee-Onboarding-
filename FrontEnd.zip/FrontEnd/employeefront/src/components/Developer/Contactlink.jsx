import React from 'react'
import Dashheader from './Dashheader'
import Contact from './Contact'
import Footer from './copyfoot'

const Contactlink = () => {
  return (
    <div>
      <Dashheader />
      <Contact />
      <Footer />
    </div>
  )
}

export default Contactlink
